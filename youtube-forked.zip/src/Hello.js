import React from 'react';

export default ({ name }) => <h1>hola {name}</h1>;
